package com.example.project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ProgressBar prgBar;

    Handler handler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message message) {
            List<NewsHome> data = (List<NewsHome>)message.obj;
            NewsRecyclerViewAdapter adp = new NewsRecyclerViewAdapter( MainActivity.this, data);
            recyclerView.setAdapter(adp);

            recyclerView.setVisibility(View.VISIBLE);
            prgBar.setVisibility(View.INVISIBLE);
            return true;
        }
    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setTitle("CS310 News");

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        TabLayout tabLayout = findViewById(R.id.tabLayout);
        ViewPager2 viewPager2 = findViewById(R.id.pager);
        prgBar = findViewById(R.id.progressBar);
        prgBar.setVisibility(View.VISIBLE);

        AdapterPage adapterPage = new AdapterPage(getSupportFragmentManager(),getLifecycle());
        viewPager2.setAdapter(adapterPage);
        tabLayout.bringToFront();
        new TabLayoutMediator(tabLayout, viewPager2, (tab, position) -> {
            tab.setText("SA" + (position +1));
        }).attach();

        recyclerView = findViewById(R.id.recyclerViewList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));


        NewsRepo repo = new NewsRepo();
        repo.getEconomyNews(((ThreadApplication) getApplication()).srv, handler);

    }
}